package osgi.spellcheck.api.wrapper;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import osgi.spellcheck.bridge.SpellcheckBridge;
import osgi.spellcheck.spellchecker.ISpellCheck;

import osgi.spellcheck.api.spellchecker.SpellCheckerImpl;

public class Activator implements BundleActivator {

    /**
     * 
     * @param bundleContext is the context for osgi
     * @throws Exception when register a delegate
     */
    public void start(BundleContext bundleContext) throws Exception {
        ISpellCheck spellCheckerImpl = new SpellCheckerImpl();
        SpellcheckBridge.getInstance().registerDelegate(spellCheckerImpl);
    }

    @Override
    public void stop(BundleContext bundleContext) throws Exception {
        // TODO Auto-generated method stub

    }

}
