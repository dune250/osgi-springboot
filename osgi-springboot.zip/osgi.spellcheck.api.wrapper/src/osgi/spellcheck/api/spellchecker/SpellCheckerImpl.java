package osgi.spellcheck.api.spellchecker;

import osgi.spellcheck.spellchecker.ISpellCheck;

public class SpellCheckerImpl implements ISpellCheck {

	@Override
	public String checkSpelling(String locale, String text, int suggestions) {
		//call real implementation of osgi bundles. 
		return "";
	}

	@Override
	public void init(int poolSize) {
	}

}
