package osgi.spellcheck.api.spellchecker;

import osgi.spellcheck.spellchecker.ISpellResult;

public class SpellResultImpl implements ISpellResult {

   
    @Override
    public String getSpellResult() {
        return "this is osgi result";
    }

}
