package osgi.spellcheck.bridge;

public final class SpellcheckBridge {

    private static final SpellcheckBridge instance = new SpellcheckBridge();
    private Object delegate;

    private SpellcheckBridge() {

    }

    public void registerDelegate(Object delegate) {
        instance.delegate = delegate;
    }

    public Object acquireDelegateReference() {
        return instance.delegate;
    }

    public static SpellcheckBridge getInstance() {
        return instance;
    }
}
