package osgi.spellcheck.spellchecker;

public interface ISpellCheck {

    void init(int poolSize);

    String checkSpelling(String locale, String text, int suggestions);
}
