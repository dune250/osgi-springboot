package osgi.spellcheck.spellchecker;

public interface ISpellResult {

    String getSpellResult();
}
