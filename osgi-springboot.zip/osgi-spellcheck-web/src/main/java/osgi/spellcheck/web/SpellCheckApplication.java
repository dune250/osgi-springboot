package osgi.spellcheck.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = { "osgi.spellcheck" })
public class SpellCheckApplication {

    /**
     * 
     * @param args the springboot application
     */
    public static void main(String[] args) {
        SpringApplication.run(SpellCheckApplication.class, args);
    }
}
