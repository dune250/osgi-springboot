package osgi.spellcheck.web.osgi;

import javax.annotation.PostConstruct;

import org.eclipse.equinox.servletbridge.FrameworkLauncher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import osgi.spellcheck.servlet.impl.SpellCheckConfig;

@Service
public class SpellCheckFrameworkLauncher extends FrameworkLauncher {

    @Value(value = "${osgi.bundles.path}")
    private String bundlesPath;

    /**
     * initialize the osgi framework
     * 
     * @throws SpellCheckException
     * 
     */
    @PostConstruct
    public void initialize() throws SpellCheckException {
        System.setProperty("osgi.bundles.path", bundlesPath);
        this.config = new SpellCheckConfig(bundlesPath);
        this.context = config.getServletContext();
        this.deploy();
        System.out.println("spellcheck platform directory is located at " + getPlatformDirectory());
        this.start();
    }

}
