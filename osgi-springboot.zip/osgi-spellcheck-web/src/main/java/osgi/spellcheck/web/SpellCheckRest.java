package osgi.spellcheck.web;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import osgi.spellcheck.bridge.SpellcheckBridge;
import osgi.spellcheck.osgi.SpellCheckFrameworkLauncher;
import osgi.spellcheck.spellchecker.ISpellCheck;

@RestController
@RequestMapping("/api/v1")
public class SpellCheckRest implements HealthIndicator {

    @Autowired
    private osgi.spellcheck.web.osgi.SpellCheckFrameworkLauncher framework;

    private ISpellCheck spellCheck;

    /**
     * init method
     */
    @PostConstruct
    public void init() {
        ISpellCheck sc = (ISpellCheck) SpellcheckBridge.getInstance().acquireDelegateReference();
        setSpellCheckInstance(sc);
        spellCheck.init(50);
    }

    public void setSpellCheckInstance(ISpellCheck instance) {
        this.spellCheck = instance;
    }

    public ISpellCheck getSpellCheckInstance() {
        return this.spellCheck;
    }

    /**
     * 
     * @param words the text you want to spellcheck
     * @param suggestions the suggestions number count
     * @return the spellcheck result
     */
    @RequestMapping(value = "/suggestions/{suggestions}", params = { "locale", "words" }, method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> spellCheck(@RequestParam("words") String words, @PathVariable("suggestions") int suggestions,
        @RequestParam(value = "locale") String locale) {

        ClassLoader cl = this.framework.getFrameworkContextClassLoader();
        ClassLoader newCL = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(cl);
        String checkResult = spellCheck.checkSpelling(locale, words, suggestions, false, 1L);
        Thread.currentThread().setContextClassLoader(newCL);
        LOGGER.info("It takes " + (System.currentTimeMillis() - start) + " milliseconds to check " + words + ", " + suggestions
            + ", " + locale + " result:" + checkResult);
        return new ResponseEntity<String>(checkResult, HttpStatus.OK);
    }

}
